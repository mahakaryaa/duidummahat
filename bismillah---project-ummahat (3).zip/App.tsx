
import React, { useState, useEffect, useLayoutEffect, useRef, useMemo } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart as RePieChart, Pie, Cell, BarChart, Bar
} from 'recharts';
import { 
  Wallet, 
  History, 
  TrendingUp, 
  TrendingDown, 
  LayoutDashboard,
  Leaf,
  Gift,
  Smile,
  Plane,
  Sun,
  Moon,
  BarChart3,
  Heart,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  PieChart as PieIcon,
  PiggyBank
} from 'lucide-react';
import { PROJECT_DATA } from './constants';

declare const gsap: any;

const COLORS = {
  projects: ['#7C9B93', '#A68B8B', '#D1D1C7', '#8E8E8E', '#A4C1B9']
};

type ProjectType = 'Semua' | 'Resik' | 'Hadeyya' | 'Siyar' | 'Haru';

const ProjectIcons: Record<string, any> = {
  'Semua': LayoutDashboard,
  'Resik': Leaf,
  'Hadeyya': Gift,
  'Siyar': Plane,
  'Haru': Smile
};

const ProjectTimelines: Record<string, string> = {
  'Semua': 'Periode 2024 - 2026',
  'Resik': 'Oktober 2024 - Januari 2026',
  'Hadeyya': 'Periode 2025 - 2026',
  'Siyar': 'Januari 2024 - Januari 2026',
  'Haru': 'Desember 2025 - Maret 2026'
};

const SkyToggle = ({ isDark, onToggle }: { isDark: boolean, onToggle: () => void }) => {
  return (
    <div className="sky-toggle" onClick={onToggle} role="button" aria-label="Ganti Tema">
      <div className="toggle-thumb">
        {isDark ? <Moon size={14} color="white" /> : <Sun size={14} color="white" />}
      </div>
    </div>
  );
};

const SummaryCard = ({ 
  title, 
  numericValue, 
  icon: Icon, 
  type, 
  className, 
  subtitle,
  variant = 'default'
}: { 
  title: string, 
  numericValue: number, 
  icon: any, 
  type: 'balance' | 'count' | 'income' | 'expense', 
  className?: string, 
  subtitle?: string,
  variant?: 'default' | 'special'
}) => {
  const valueRef = useRef<HTMLParagraphElement>(null);
  
  useLayoutEffect(() => {
    if (valueRef.current) {
      const obj = { val: 0 };
      gsap.to(obj, {
        val: numericValue,
        duration: 1.5,
        ease: "power3.out",
        onUpdate: () => {
          if (valueRef.current) {
            valueRef.current.textContent = type === 'count' 
              ? Math.floor(obj.val).toString() 
              : `Rp ${Math.floor(obj.val).toLocaleString('id-ID')}`;
          }
        }
      });
    }
  }, [numericValue, type]);

  const isSpecial = variant === 'special';

  return (
    <div className={`clay-card p-6 md:p-8 flex flex-col items-center justify-center text-center opacity-0 ${isSpecial ? 'clay-card-grid bg-rose-50/20' : ''} ${className}`}>
      <div className="relative mb-4">
          <div className={`w-14 h-14 flex items-center justify-center rounded-[22px] clay-inset ${isSpecial ? 'bg-rose-100/30' : ''}`}>
            <Icon className={`w-7 h-7 ${isSpecial ? 'text-rose-400' : 'text-[#7C9B93]'}`} strokeWidth={2.5} />
          </div>
      </div>
      <div className="flex flex-col items-center w-full">
        <p className="text-[10px] md:text-[12px] font-black uppercase tracking-widest mb-1 text-muted">{title}</p>
        <p ref={valueRef} className={`text-[18px] md:text-[20px] font-black tracking-tight leading-tight ${isSpecial ? 'text-rose-500/80' : 'text-main'}`}>Rp 0</p>
        {subtitle && (
          <div className={`mt-2.5 px-3 py-0.5 rounded-full border shadow-sm ${isSpecial ? 'bg-rose-100/50 border-rose-200' : 'bg-[#7C9B93]/10 border-[#7C9B93]/20'}`}>
            <p className={`text-[8px] font-black uppercase tracking-widest ${isSpecial ? 'text-rose-400' : 'text-[#7C9B93]'}`}>{subtitle}</p>
          </div>
        )}
      </div>
    </div>
  );
};

const CustomTooltip = ({ active, payload, isDark }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const value = payload[0].value;
    const displayValue = `Rp ${Math.floor(value).toLocaleString('id-ID')}`;

    return (
      <div className="clay-card p-4 border-none shadow-2xl scale-105">
        <p className="text-[13px] font-bold text-main mb-1.5">{payload[0].name || data.month || data.name}</p>
        <p className="text-[16px] font-black text-[#7C9B93]">
          {displayValue}
        </p>
      </div>
    );
  }
  return null;
};

const WelcomeSection = () => {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="clay-card overflow-hidden p-8 md:p-12 relative fade-in-section">
      <div className="welcome-blob bg-[#7C9B93] w-[300px] h-[300px] -top-20 -left-20"></div>
      <div className="welcome-blob bg-[#A68B8B] w-[200px] h-[200px] -bottom-10 -right-10"></div>
      
      <div className="flex flex-col md:flex-row md:items-center gap-6 mb-8">
        <div className="w-16 h-16 clay-inset flex items-center justify-center text-[#7C9B93]">
          <ShieldCheck size={32} strokeWidth={2.5} />
        </div>
        <div>
            <h2 className="text-[18px] md:text-[22px] font-black uppercase tracking-widest text-main mb-1">Menjaga Amanah</h2>
            <div className="h-1.5 w-24 bg-[#7C9B93] rounded-full opacity-40" />
        </div>
      </div>
      
      <div className={`text-[15px] md:text-[17px] font-medium leading-relaxed text-main transition-all duration-700 ease-in-out ${!expanded ? 'max-md:max-h-[100px] overflow-hidden' : ''}`}>
        <p className="mb-6 opacity-90">
          Halaman ini adalah jendela transparansi bagi seluruh proyek yang dikelola oleh Ummahat Kuttab Al-Fatih Kediri. Kami menyadari bahwa setiap rupiah yang dititipkan adalah amanah besar yang akan dipertanggungjawabkan di hadapan Allah ta'ala.
        </p>
        <div className="p-6 clay-inset bg-[#7C9B93]/5 rounded-3xl">
          <p className="italic text-muted font-medium">
            "Semoga setiap harta yang dikeluarkan menjadi pembersih bagi jiwa dan pemberat timbangan kebaikan di akhirat kelak. Aamiin."
          </p>
        </div>
      </div>
      
      <button 
        onClick={() => setExpanded(!expanded)}
        className="md:hidden mt-6 flex items-center gap-2 px-6 py-3 rounded-full clay-button text-[12px] font-black uppercase text-[#7C9B93]"
      >
        {expanded ? <><ChevronUp size={16}/> Tutup</> : <><ChevronDown size={16}/> Selengkapnya</>}
      </button>
    </div>
  );
};

const App: React.FC = () => {
  const [activeProject, setActiveProject] = useState<ProjectType>('Semua');
  const [filter, setFilter] = useState<'all' | 'income' | 'expense'>('all');
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    if (isDark) document.body.classList.add('dark-mode');
    else document.body.classList.remove('dark-mode');
  }, [isDark]);

  const aggregatedData = useMemo(() => {
    const allProjects = ['Resik', 'Siyar', 'Hadeyya', 'Haru'];
    let totalBalance = 0, totalIncome = 0, totalExpense = 0;
    let allTransactions: any[] = [];
    const projectBalanceContributions: any[] = [];

    allProjects.forEach((key, idx) => {
      const p = PROJECT_DATA[key];
      totalBalance += p.summary.balance;
      totalIncome += p.summary.income;
      totalExpense += p.summary.expense;
      allTransactions = [...allTransactions, ...p.transactions.map(t => ({ ...t, project: key }))];
      
      projectBalanceContributions.push({
        name: key,
        value: p.summary.balance,
        color: COLORS.projects[idx % COLORS.projects.length]
      });
    });

    allTransactions.sort((a, b) => {
      const dateA = new Date(a.date.split('/').reverse().join('-')).getTime();
      const dateB = new Date(b.date.split('/').reverse().join('-')).getTime();
      return dateB - dateA;
    });

    return {
      summary: { balance: totalBalance, income: totalIncome, expense: totalExpense },
      transactions: allTransactions,
      projectBalanceContributions,
      monthlyFlow: PROJECT_DATA['Resik'].monthlyFlow.map((f, i) => ({
        month: f.month,
        income: allProjects.reduce((acc, k) => acc + (PROJECT_DATA[k].monthlyFlow[i]?.income || 0), 0),
        expense: allProjects.reduce((acc, k) => acc + (PROJECT_DATA[k].monthlyFlow[i]?.expense || 0), 0),
      }))
    };
  }, []);

  const resikStats = useMemo(() => {
    const resikTransactions = PROJECT_DATA['Resik'].transactions;
    
    // Perhitungan yang lebih akurat untuk dana 'Disalurkan'
    const distributed = resikTransactions.reduce((acc, tx) => {
      const desc = tx.description.toLowerCase();
      // Mengambil item Penyaluran/Disalurkan yang bukan merupakan alokasi tabungan
      if ((desc.includes('salur') || (desc.includes('cinta guru') && !desc.includes('tabungan'))) && tx.expense) {
        return acc + tx.expense;
      }
      return acc;
    }, 0);

    const savings = resikTransactions.reduce((acc, tx) => {
      const desc = tx.description.toLowerCase();
      if (desc.includes('tabungan') && tx.expense) {
        return acc + tx.expense;
      }
      return acc;
    }, 0);
    
    return { savings, distributed };
  }, []);

  const currentData = activeProject === 'Semua' ? aggregatedData : PROJECT_DATA[activeProject];
  const Icon = ProjectIcons[activeProject];
  const Timeline = ProjectTimelines[activeProject];

  const pieData = useMemo(() => {
    if (activeProject === 'Semua') {
      return aggregatedData.projectBalanceContributions;
    }
    const categories = (currentData as any).expenseCategories || [];
    const totalAmount = currentData.summary.expense;
    return categories.map((cat: any) => ({
      ...cat,
      nominal: Math.round((cat.value / 100) * totalAmount)
    }));
  }, [activeProject, currentData, aggregatedData]);

  useLayoutEffect(() => {
    gsap.fromTo(".card-anim", { y: 20, opacity: 0, scale: 0.9 }, { y: 0, opacity: 1, scale: 1, duration: 0.5, ease: "back.out(1.7)", stagger: 0.08 });
    gsap.fromTo(".fade-in-section", { opacity: 0 }, { opacity: 1, duration: 1 });
  }, [activeProject]);

  const projects: ProjectType[] = ['Semua', 'Resik', 'Hadeyya', 'Siyar', 'Haru'];

  const filteredTransactions = currentData.transactions.filter(t => {
    if (filter === 'all') return true;
    return filter === 'income' ? t.income !== null : t.expense !== null;
  });

  return (
    <div className="min-h-screen p-4 md:p-10 max-w-7xl mx-auto space-y-12 pb-40">
      
      <header className="flex justify-between items-center fade-in-section">
        <div className="flex items-center space-x-6">
            <div className="w-16 h-16 clay-card flex items-center justify-center">
                <Icon className="text-[#7C9B93]" size={32} />
            </div>
            <div>
                <h1 className="text-[12px] font-black uppercase tracking-[0.25em] text-muted mb-1">Project Ummahat</h1>
                <div className="flex flex-col">
                  <p className="text-[28px] md:text-[36px] font-black text-main leading-none">{activeProject}</p>
                  <p className="text-[10px] font-black text-[#7C9B93] uppercase tracking-[0.2em] mt-1">{Timeline}</p>
                </div>
            </div>
        </div>
        <SkyToggle isDark={isDark} onToggle={() => setIsDark(!isDark)} />
      </header>

      <nav className="hidden md:flex justify-center fade-in-section">
        <div className="clay-inset p-3 flex gap-3">
          {projects.map((proj) => (
            <button key={proj} onClick={() => setActiveProject(proj)}
              className={`clay-button ${activeProject === proj ? 'active' : ''}`}
            >
              {proj}
            </button>
          ))}
        </div>
      </nav>

      {activeProject === 'Semua' && <WelcomeSection />}

      <div className={`grid grid-cols-1 sm:grid-cols-2 ${activeProject === 'Resik' ? 'lg:grid-cols-5' : 'lg:grid-cols-4'} gap-8`}>
        <SummaryCard title="Total Saldo" numericValue={currentData.summary.balance} icon={Wallet} type="balance" className="card-anim" />
        
        {activeProject === 'Resik' && (
          <>
            <SummaryCard title="Tabungan Cinta Guru" numericValue={resikStats.savings} icon={Heart} type="expense" variant="special" className="card-anim" subtitle="Di Bendahara" />
            <SummaryCard title="Disalurkan" numericValue={resikStats.distributed} icon={Heart} type="expense" variant="special" className="card-anim" subtitle="Ramadhan Lalu" />
          </>
        )}
        
        <SummaryCard title="Transaksi" numericValue={currentData.transactions.length} icon={History} type="count" className="card-anim" />
        <SummaryCard title="Total Masuk" numericValue={currentData.summary.income} icon={TrendingUp} type="income" className="card-anim" />
        <SummaryCard title="Total Keluar" numericValue={currentData.summary.expense} icon={TrendingDown} type="expense" className="card-anim" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 fade-in-section">
        <div className="lg:col-span-2 clay-card p-10">
            <h3 className="text-[12px] font-black uppercase tracking-widest text-main flex items-center gap-3 mb-12">
                <div className="p-2 clay-inset text-[#7C9B93]"><BarChart3 size={18} /></div>
                Visualisasi Arus Kas
            </h3>
            <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                    {activeProject === 'Semua' ? (
                        <BarChart data={aggregatedData.projectBalanceContributions} layout="vertical" margin={{ left: 20 }}>
                            <XAxis type="number" hide />
                            <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 800, fill: 'var(--text-main)' }} width={80} />
                            <Tooltip content={<CustomTooltip isDark={isDark} />} cursor={{ fill: 'transparent' }} />
                            <Bar dataKey="value" radius={[0, 15, 15, 0]} barSize={30}>
                                {aggregatedData.projectBalanceContributions.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Bar>
                        </BarChart>
                    ) : (
                        <AreaChart data={currentData.monthlyFlow}>
                          <defs>
                            <linearGradient id="colorIn" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#7C9B93" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#7C9B93" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorOut" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#A68B8B" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#A68B8B" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="8 8" vertical={false} stroke="var(--clay-shadow-out-dark)" opacity={0.5} />
                          <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 800, fill: 'var(--text-muted)' }} />
                          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 800, fill: 'var(--text-muted)' }} tickFormatter={(v) => v >= 1000000 ? `${v/1000000}jt` : v} />
                          <Tooltip content={<CustomTooltip isDark={isDark} />} />
                          <Area type="monotone" dataKey="income" stroke="#7C9B93" strokeWidth={4} fill="url(#colorIn)" />
                          <Area type="monotone" dataKey="expense" stroke="#A68B8B" strokeWidth={4} fill="url(#colorOut)" />
                        </AreaChart>
                    )}
                </ResponsiveContainer>
            </div>
        </div>

        <div className="clay-card p-10 flex flex-col items-center">
             <h3 className="text-[12px] font-black uppercase tracking-widest text-main mb-12 flex items-center gap-3">
                 <div className="p-2 clay-inset text-[#7C9B93]"><PieIcon size={18} /></div>
                 {activeProject === 'Semua' ? 'Alokasi Dana' : 'Penyaluran'}
             </h3>
             <div className="h-[260px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                        <Pie data={pieData} cx="50%" cy="50%" innerRadius="65%" outerRadius="90%" dataKey="value" paddingAngle={8} cornerRadius={12}>
                            {pieData.map((e: any, i: number) => (
                              <Cell key={i} fill={e.color || COLORS.projects[i % COLORS.projects.length]} stroke="none" />
                            ))}
                        </Pie>
                        <Tooltip content={<CustomTooltip isDark={isDark} />} />
                    </RePieChart>
                </ResponsiveContainer>
             </div>
             <div className="mt-8 space-y-4 w-full">
                {pieData.map((p: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-4 clay-inset rounded-[24px]">
                        <div className="flex items-center gap-3">
                            <div className="w-4 h-4 rounded-full" style={{ background: p.color || COLORS.projects[i % COLORS.projects.length] }} />
                            <span className="text-[11px] font-black uppercase text-main">{p.name}</span>
                        </div>
                        <span className="badge-clay text-muted">{activeProject === 'Semua' ? `${Math.round((p.value / aggregatedData.summary.balance) * 100)}%` : `${p.value}%`}</span>
                    </div>
                ))}
             </div>
        </div>
      </div>

      <div className="clay-card p-6 md:p-10 fade-in-section">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
          <h3 className="text-[16px] font-black uppercase tracking-widest text-main flex items-center gap-3">
            <History size={20} className="text-[#7C9B93]" /> Riwayat Transaksi
          </h3>
          <div className="clay-inset p-2 flex gap-2">
            {(['all', 'income', 'expense'] as const).map((m) => (
              <button key={m} onClick={() => setFilter(m)} className={`px-6 py-2 rounded-full text-[11px] font-black uppercase transition-all ${filter === m ? 'clay-card !bg-[#7C9B93] text-white' : 'text-muted'}`}>
                {m === 'all' ? 'Semua' : m === 'income' ? 'Masuk' : 'Keluar'}
              </button>
            ))}
          </div>
        </div>
        <div className="table-scroll-container no-scrollbar">
          <table className="w-full border-separate border-spacing-y-4 min-w-[600px]">
            <thead>
              <tr className="text-[10px] font-black uppercase tracking-widest text-muted">
                <th className="px-6 py-2 text-left w-20">#</th>
                <th className="px-6 py-2 text-left w-32">Tanggal</th>
                <th className="px-6 py-2 text-left">Uraian</th>
                <th className="px-6 py-2 text-right w-48">Jumlah</th>
              </tr>
            </thead>
            <tbody className="text-[14px]">
              {filteredTransactions.slice(0, 100).map((tx, i) => (
                <tr key={i} className="group">
                  <td className="px-6 py-5 rounded-l-[24px] clay-inset shadow-none bg-white/20"><span className="font-black text-muted">{(i + 1).toString().padStart(2, '0')}</span></td>
                  <td className="px-6 py-5 font-black text-muted text-[12px]">{tx.date}</td>
                  <td className="px-6 py-5 font-black uppercase text-[12px] tracking-tight text-main">{tx.description}</td>
                  <td className="px-6 py-5 text-right rounded-r-[24px] whitespace-nowrap">
                     <span className={`font-black ${tx.income ? 'text-[#7C9B93]' : 'text-[#A68B8B]'}`}>{tx.income ? `+ ${tx.income.toLocaleString('id-ID')}` : `- ${tx.expense?.toLocaleString('id-ID')}`}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 md:hidden w-[90%]">
        <div className="clay-card p-2 flex items-center justify-between gap-1 overflow-x-auto no-scrollbar">
          {projects.map((proj) => {
            const ProjIcon = ProjectIcons[proj];
            const isActive = activeProject === proj;
            return (
              <button key={proj} onClick={() => setActiveProject(proj)} className={`flex flex-col items-center justify-center p-3 rounded-[24px] flex-1 min-w-[60px] transition-all ${isActive ? 'clay-inset text-[#7C9B93]' : 'text-muted'}`}>
                <ProjIcon size={18} />
                <span className="text-[8px] font-black uppercase mt-1">{proj}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default App;
